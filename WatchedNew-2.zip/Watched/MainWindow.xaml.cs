﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Watched.Windows;
using WatchedNew.Units;

namespace Watched {
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e) {

            List<DateTime> Gesehen1 = new List<DateTime>();
            Gesehen1.Add(DateTime.Now);
            Gesehen1.Add(DateTime.Now.AddDays(1));
            Gesehen1.Add(DateTime.Now.AddDays(2));

            FolgeEdit Edit = new FolgeEdit((Folge)(new Folge(2, Gesehen1).Clone()));

            Edit.ShowDialog();

            var bla = Edit.Return;
        }

        private void Staffel_Click(object sender, RoutedEventArgs e) {

            List<DateTime> Gesehen1 = new List<DateTime>();
            Gesehen1.Add(DateTime.Now);
            Gesehen1.Add(DateTime.Now.AddDays(1));
            Gesehen1.Add(DateTime.Now.AddDays(2));

            List<Folge> FStaffel1 = new List<Folge>();
            FStaffel1.Add(new Folge(1));
            FStaffel1.Add(new Folge(2, Gesehen1));
            FStaffel1.Add(new Folge(3));
            FStaffel1.Add(new Folge(4));

            List<Folge> FStaffel2 = new List<Folge>();
            FStaffel2.Add(new Folge(1));
            FStaffel2.Add(new Folge(2));
            FStaffel2.Add(new Folge(3));
            FStaffel2.Add(new Folge(4, Gesehen1));

            ObservableCollection<Staffel> LostStaffeln = new ObservableCollection<Staffel>();
            LostStaffeln.Add(new Staffel(1, FStaffel1));
            LostStaffeln.Add(new Staffel(2, FStaffel2));

            SerieStaffelEdit Edit = new SerieStaffelEdit(LostStaffeln);
            Edit.ShowDialog();
        }
    }
}
