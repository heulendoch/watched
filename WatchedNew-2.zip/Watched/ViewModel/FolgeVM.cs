﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WatchedNew.Units;

namespace Watched.ViewModel {

    public class FolgeVM : Folge, IRequiredCommands {

        public FolgeVM(Folge Object) : this(Object.Nummer, Object.ZeitpunktGesehen, Object.Name) { 
        
        }

        public FolgeVM(int Nummer, IEnumerable<DateTime> ZeitpunktGesehen = null, string Name = "") : base(Nummer, ZeitpunktGesehen, Name) { 
        
        }

        public System.Windows.Input.ICommand ComEdit() {
            throw new NotImplementedException();
        }

        public System.Windows.Input.ICommand ComDelete() {
            throw new NotImplementedException();
        }
    }



}
