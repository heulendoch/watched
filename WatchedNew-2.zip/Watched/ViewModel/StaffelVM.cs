﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WatchedNew.Units;

namespace Watched.ViewModel {
    
    public class StaffelVM : Staffel, IRequiredCommands {

        public StaffelVM(Staffel Object) : this(Object.Nummer, Object.Folgen, Object.Name) { 
        
        }

        public StaffelVM(int Nummer, IEnumerable<Folge> Folgen = null, string Name = "") : base(Nummer, Folgen, Name) { 
        
        }

        public System.Windows.Input.ICommand ComEdit() {
            throw new NotImplementedException();
        }

        public System.Windows.Input.ICommand ComDelete() {
            throw new NotImplementedException();
        }
    }
}
