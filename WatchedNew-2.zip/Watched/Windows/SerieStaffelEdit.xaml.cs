﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WatchedNew.Units;

namespace Watched.Windows {
    /// <summary>
    /// Interaktionslogik für SerieStaffelEdit.xaml
    /// </summary>
    public partial class SerieStaffelEdit : Window {


        public SerieStaffelEdit(ObservableCollection<Staffel> Staffeln = null) {
            InitializeComponent();
            this.cbStaffeln.ItemsSource = Staffeln;
        }

        private void AddStaffel(object sender, RoutedEventArgs e) {
            int Nummer = int.MinValue;
            if (int.TryParse(this.tbStaffelNummer.Text, out Nummer)) {
                ((ObservableCollection<Staffel>)cbStaffeln.ItemsSource).Add(new Staffel(Nummer, null, this.tbStaffelName.Text));
                this.tbStaffelNummer.Text = string.Empty;
                this.tbStaffelName.Text = string.Empty;
            }
        }

        private void AddFolge(object sender, RoutedEventArgs e) {
            int Nummer = int.MinValue;
            if (int.TryParse(this.tbFolgeNummer.Text, out Nummer)) {
                ((Staffel)cbStaffeln.SelectedItem).Folgen.Add(new Folge(Nummer, null, this.tbFolgeName.Text));
                this.tbFolgeNummer.Text = string.Empty;
                this.tbFolgeName.Text = string.Empty;
            }
        }

        private void RemoveStaffel(object sender, RoutedEventArgs e) {
            try {
                ((ObservableCollection<Staffel>)cbStaffeln.ItemsSource).Remove(((Staffel)cbStaffeln.SelectedItem));
                cbStaffeln.SelectedIndex = 0;
            }
            catch {
                MessageBox.Show("Entfernen nicht möglich.");
            }
        }

        private void EditFolge(object sender, MouseButtonEventArgs e) {

            FrameworkElement CurrentSender = (FrameworkElement)sender;
            Folge CurrentFolge = (Folge)CurrentSender.Tag;

            FolgeEdit Edit = new FolgeEdit((Folge)CurrentFolge.Clone());

            if ((bool)Edit.ShowDialog()) {
                Staffel CurrentStaffel = (Staffel)cbStaffeln.SelectedItem;
                int Index = CurrentStaffel.Folgen.IndexOf(CurrentFolge);
                CurrentStaffel.Folgen.Remove(CurrentFolge);
                CurrentStaffel.Folgen.Insert(Index, (Folge)Edit.Return);
            }
        }

        private void RemoveFolge(object sender, MouseButtonEventArgs e) {
            FrameworkElement CurrentSender = (FrameworkElement)sender;
            Folge CurrentFolge = (Folge)CurrentSender.Tag;

            FolgeEdit Edit = new FolgeEdit((Folge)CurrentFolge.Clone());

            if (MessageBox.Show("Wirklich löschen?", "Löschen?", MessageBoxButton.OKCancel) == MessageBoxResult.OK) {
                Staffel CurrentStaffel = (Staffel)cbStaffeln.SelectedItem;
                CurrentStaffel.Folgen.Remove(CurrentFolge);
            }
        }



    }
}
