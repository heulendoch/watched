﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using WatchedNew.Units;

namespace WatchedKonsole {
    class Program {
        static void Main(string[] args) {

            string XmlFile = @"C:\tmp\lost.xml";
            File.Delete(XmlFile);

            List<DateTime> Gesehen1 = new List<DateTime>();
            Gesehen1.Add(DateTime.Now);
            Gesehen1.Add(DateTime.Now.AddDays(1));
            Gesehen1.Add(DateTime.Now.AddDays(2));

            List<Folge> FStaffel1 = new List<Folge>();
            FStaffel1.Add(new Folge(1));
            FStaffel1.Add(new Folge(2, Gesehen1));
            FStaffel1.Add(new Folge(3));
            FStaffel1.Add(new Folge(4));

            List<Folge> FStaffel2 = new List<Folge>();
            FStaffel2.Add(new Folge(1));
            FStaffel2.Add(new Folge(2));
            FStaffel2.Add(new Folge(3));
            FStaffel2.Add(new Folge(4, Gesehen1));
            
            List<Staffel> LostStaffeln = new List<Staffel>();
            LostStaffeln.Add(new Staffel(1, FStaffel1));
            LostStaffeln.Add(new Staffel(2, FStaffel2));

            Serie CurrentSerie = new Serie("Lost", LostStaffeln);

            XDocument Doc = new XDocument();
            Doc.Add(CurrentSerie.ToXML());
            Doc.Save(XmlFile);

            XDocument DocLoad = XDocument.Load(XmlFile);
            Serie Lost = SerieFactory.FromXElement(DocLoad.Root);

            Console.ReadKey();


        }
    }
}
