﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace WatchedNew.Units {
    
    public class Folge : IXml, INotifyPropertyChanged, ICloneable {

        public const string DefaultName = "(Empty)";

        /// <summary>
        /// Nummer der Folge
        /// </summary>
        private int m_Nummer;
        
        /// <summary>
        /// Name der Folge
        /// </summary>
        private string m_Name;

        /// <summary>
        /// Zeitpunkte zu dem die Folge gesehen wurde
        /// </summary>
        private ObservableCollection<DateTime> m_ZeitpunktGesehen = new ObservableCollection<DateTime>();


        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Nummer">Nummer der Folge</param>
        /// <param name="Name">Name der Folge</param>
        public Folge(int Nummer, IEnumerable<DateTime> ZeitpunktGesehen = null, string Name = "") {
            this.Nummer = Nummer;
            
            if (ZeitpunktGesehen != null) { 
                foreach(DateTime Current in ZeitpunktGesehen){
                    this.ZeitpunktGesehen.Add(Current);
                }
                
            }

            this.Name = Folge.DefaultName;
            if (!string.IsNullOrWhiteSpace(Name)) {
                this.Name = Name;
            }

            
        }

        /// <summary>
        /// Nummer der Folge
        /// </summary>
        public int Nummer {
            get { return this.m_Nummer; }
            set {
                this.m_Nummer = value;
                this.OnPropertyChanged("Nummer");
            }
        }

        /// <summary>
        /// Name der Folge
        /// </summary>
        public string Name {
            get { return this.m_Name; }
            set { 
                this.m_Name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Zeitpunkte zu dem die Folge gesehen wurde
        /// </summary>
        public ObservableCollection<DateTime> ZeitpunktGesehen {
            get { return this.m_ZeitpunktGesehen; }
            private set {
                this.m_ZeitpunktGesehen = value;
                this.OnPropertyChanged("ZeitpunktGesehen");
            }
        }

        /// <summary>
        /// Der letzte Zeitpunkt zu dem die Folge gesehen wurde
        /// </summary>
        public DateTime ZeitpunktGesehenZuletzt {
            get { return this.ZeitpunktGesehen.OrderByDescending(Current => Current.Ticks).FirstOrDefault(); }
            private set {
                
                this.OnPropertyChanged("ZeitpunktGesehen");
            }
        }


        #region Interfaces

        public XElement ToXML() {
            XElement Current = new XElement(typeof(Folge).Name);
            Current.Add(new XAttribute(Folge.XmlAttrNummer, this.Nummer));
            Current.Add(new XAttribute(Folge.XmlAttrName, this.Name));

            XElement CurrentGesehen = new XElement(Folge.XmlEleGesehen);
            foreach (DateTime DTCurrent in this.ZeitpunktGesehen) {
                CurrentGesehen.Add(new XElement(typeof(DateTime).Name, new XAttribute("Ticks", DTCurrent.Ticks))); 
            }
            Current.Add(CurrentGesehen);

            return Current;
        }

        protected virtual void OnPropertyChanged(string PropertyName) {
            Helper.VerifyPropertyName(this, PropertyName);
            PropertyChangedEventHandler Handler = this.PropertyChanged;
            if (Handler != null) {
                Handler(this, new PropertyChangedEventArgs(PropertyName));
            }
        }

        public object Clone() {
            return new Folge(this.Nummer, this.ZeitpunktGesehen, this.Name);
        }

        #endregion

        public const string XmlAttrNummer = "Nummer";
        public const string XmlAttrName = "Name";
        public const string XmlEleGesehen = "Gesehen";

        public const string XmlListe = "ListeFolge";



    }
}
