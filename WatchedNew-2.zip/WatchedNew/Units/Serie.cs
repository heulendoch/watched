﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace WatchedNew.Units {
    
    public class Serie : IXml, INotifyPropertyChanged {

        /// <summary>
        /// Name der Serie
        /// </summary>
        private string m_Name;

        /// <summary>
        /// Staffeln der Serie
        /// </summary>
        private ObservableCollection<Staffel> m_Staffeln = new ObservableCollection<Staffel>();


        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Name">Name der Serie</param>
        /// <param name="Staffeln"></param>
        public Serie(string Name, IEnumerable<Staffel> Staffeln = null) {

            if (string.IsNullOrWhiteSpace(Name)) {
                throw new ArgumentException();
            }
            
            this.Name = Name;

            if (Staffeln != null) {
                foreach (Staffel Current in Staffeln) {
                    this.Staffeln.Add(Current);
                }

            }

        }

        /// <summary>
        /// Name der Serie
        /// </summary>
        public string Name {
            get { return this.m_Name; }
            set { 
                this.m_Name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Staffeln der Serie
        /// </summary>
        public ObservableCollection<Staffel> Staffeln {
            get { return this.m_Staffeln; }
            set {

                if (value == null) {
                    throw new ArgumentNullException();
                }
                
                this.m_Staffeln = value;
                this.OnPropertyChanged("Staffeln");
            }
        }

        #region Interfaces

        public XElement ToXML() {

            XElement Current = new XElement(typeof(Serie).Name);
            Current.Add(new XAttribute(Serie.XmlAttrName, this.Name));

            XElement CurrentStaffeln = new XElement(Staffel.XmlListe);
            foreach (Staffel CurrentStaffel in this.Staffeln) {
                CurrentStaffeln.Add(CurrentStaffel.ToXML());
            }

            Current.Add(CurrentStaffeln);

            return Current;
        }

        protected virtual void OnPropertyChanged(string PropertyName) {
            Helper.VerifyPropertyName(this, PropertyName);
            PropertyChangedEventHandler Handler = this.PropertyChanged;
            if (Handler != null) {
                Handler(this, new PropertyChangedEventArgs(PropertyName));
            }
        }

        #endregion

        public const string XmlAttrName = "Name";
        
    }
}
