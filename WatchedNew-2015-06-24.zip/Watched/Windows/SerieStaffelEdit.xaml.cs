﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Core.Units;
using Core;

namespace Watched.Windows {
    /// <summary>
    /// Interaktionslogik für SerieStaffelEdit.xaml
    /// </summary>
    public partial class SerieStaffelEdit : Window {


        public SerieStaffelEdit(ObservableCollection<Staffel> Staffeln = null, string Serienname = "") {
            InitializeComponent();

            if (Staffeln == null) {
                Staffeln = new ObservableCollection<Staffel>();
            }

            this.Title = Serienname;

            this.cbStaffeln.ItemsSource = Staffeln;
        }

        public object Return {
            get { return this.cbStaffeln.ItemsSource; }
        }

        private void AddStaffel(object sender, RoutedEventArgs e) {
            int Nummer = int.MinValue;
            if (int.TryParse(this.tbStaffelNummer.Text, out Nummer)) {
                ((ObservableCollection<Staffel>)cbStaffeln.ItemsSource).Add(new Staffel(Nummer, null, this.tbStaffelName.Text));
                this.tbStaffelNummer.Text = string.Empty;
                this.tbStaffelName.Text = string.Empty;
            }
        }

        private void AddFolge(object sender, RoutedEventArgs e) {
            int Nummer = int.MinValue;
            if (int.TryParse(this.tbFolgeNummer.Text, out Nummer)) {
                ((Staffel)cbStaffeln.SelectedItem).Folgen.Add(new Folge(Nummer, null, this.tbFolgeName.Text));
                this.tbFolgeNummer.Text = string.Empty;
                this.tbFolgeName.Text = string.Empty;
            }
        }

        private void RemoveStaffel(object sender, RoutedEventArgs e) {
            try {
                if (MessageBox.Show("Wirklich löschen?", "Löschen?", MessageBoxButton.OKCancel) == MessageBoxResult.OK) {
                    ((ObservableCollection<Staffel>)cbStaffeln.ItemsSource).Remove(((Staffel)cbStaffeln.SelectedItem));
                    cbStaffeln.SelectedIndex = 0;
                }
            }
            catch(Exception ex) {
                MessageBox.Show(ex.Message, "Staffel entfernen nicht möglich.");
            }
        }

        private void EditStaffel(object sender, RoutedEventArgs e) {
            try {
                Staffel Current = (Staffel)cbStaffeln.SelectedItem;
                MessageBox.Show(Current.Nummer + " => " + Current.Name);
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Staffel bearbeiten nicht möglich.");
            }
        }

        private void EditFolge(object sender, MouseButtonEventArgs e) {

            FrameworkElement CurrentSender = (FrameworkElement)sender;
            Folge CurrentFolge = (Folge)CurrentSender.Tag;

            FolgeEdit Edit = new FolgeEdit((Folge)CurrentFolge.Clone());

            if ((bool)Edit.ShowDialog()) {
                Staffel CurrentStaffel = (Staffel)cbStaffeln.SelectedItem;
                CurrentStaffel.Folgen.Replace(CurrentFolge, (Folge)Edit.Return);
            }
        }

        private void RemoveFolge(object sender, MouseButtonEventArgs e) {
            FrameworkElement CurrentSender = (FrameworkElement)sender;
            Folge CurrentFolge = (Folge)CurrentSender.Tag;

            if (MessageBox.Show("Wirklich löschen?", "Löschen?", MessageBoxButton.OKCancel) == MessageBoxResult.OK) {
                Staffel CurrentStaffel = (Staffel)cbStaffeln.SelectedItem;
                CurrentStaffel.Folgen.Remove(CurrentFolge);
            }
        }

        private void ButtonSave(object sender, RoutedEventArgs e) {
            this.DialogResult = true;
            this.Close();
        }





    }
}
