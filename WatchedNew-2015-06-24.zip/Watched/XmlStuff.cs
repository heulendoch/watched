﻿using Core;
using Core.Units;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Watched {
    public static class XmlStuff {

        private const string XmlRoot = "Root";

        public static XDocument LoadXml() {
            return XDocument.Load(Helper.DataFilePathDefault());
        }

        public static bool Load(ref ObservableCollection<Serie> Serien) {
            if (File.Exists(Helper.DataFilePathDefault())) {

                try {
                    XDocument DocLoad = LoadXml();

                    foreach (XElement Current in DocLoad.Root.Elements("Serie")) {
                        Serien.Add(SerieFactory.FromXElement(Current));
                    }

                    return true;
                }
                catch {
                    return false;
                }
            }

            return true;
        }

        private static XDocument SaveXml(Collection<Serie> Serien) {
            XDocument Doc = new XDocument();

            XElement Root = new XElement(XmlStuff.XmlRoot);
            foreach (Serie Current in Serien) {
                Root.Add(Current.ToXML());
            }

            Doc.Add(Root);

            return Doc;
        }

        public static void Save(Collection<Serie> Serien) {
            XDocument Doc = SaveXml(Serien);
            Doc.Save(Helper.DataFilePathDefault());
        }

        public static bool SaveRequired(Collection<Serie> Serien) {
            
            string TextOfSaveXml = XmlStuff.SaveXml(Serien).ToString();

            if (!File.Exists(Helper.DataFilePathDefault())) {

                return !TextOfSaveXml.EndsWith(string.Format("<{0} />", XmlStuff.XmlRoot));
            }
            else {
                return XmlStuff.LoadXml().ToString() != TextOfSaveXml;
            }

            
        }

    }
}
