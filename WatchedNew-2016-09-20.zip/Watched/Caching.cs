﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;

namespace Watched {
    public class Caching {

        public static Dictionary<int, BitmapImage> ImagesTvShowSearch = new Dictionary<int, BitmapImage>();

    }
}
