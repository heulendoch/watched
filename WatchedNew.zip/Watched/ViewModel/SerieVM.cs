﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WatchedNew.Units;

namespace Watched.ViewModel {

    public class SerieVM : Serie, IRequiredCommands {

        public SerieVM(Serie Object) : this(Object.Name, Object.Staffeln) { 
        
        }

        public SerieVM(string Name, IEnumerable<Staffel> Staffeln = null) : base(Name, Staffeln) { 
        
        }

        public System.Windows.Input.ICommand ComEdit() {
            throw new NotImplementedException();
        }

        public System.Windows.Input.ICommand ComDelete() {
            throw new NotImplementedException();
        }
    }
}
